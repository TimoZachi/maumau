

<?php $__env->startSection('styles'); ?>
    @parent

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('wrapper'); ?>
<!-- INIT SIDEBAR -->
<?php echo $__env->make('admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END SIDEBAR -->

<div class="main-panel">

    <!-- INIT NAVBAR -->
    <?php echo App::make('\MauMau\Http\Controllers\Admin\IndexController')->navbar()->render(); ?>
    <!-- END NAVBAR -->

    <!-- INIT CONTENT -->
    <div class="content">
        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <!-- END CONTENT -->

    <!-- INIT FOOTER -->
    <?php echo $__env->make('admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- END FOOTER -->

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    @parent

    <script type="text/javascript" src="<?php echo e(asset('assets/js/admin/demo.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/both.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/admin/admin.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.raw', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>