<!DOCTYPE html>
<html lang="pt-BR">
<head>

    <meta charset="UTF-8">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.ico')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <title>MauMau - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Bootstrap core CSS     -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/both.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>

<div class="container-fluid wrapper">
    <!-- INIT NAVBAR -->
    <?php echo App::make('\MauMau\Http\Controllers\IndexController')->navbar()->render(); ?>
    <!-- END NAVBAR -->

    <!-- INIT CONTENT -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- END CONTENT -->
</div>

<?php echo $__env->yieldContent('modals'); ?>

<!--   Core JS Files   -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-1.10.2.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

<!--  Notifications Plugin    -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/notify.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('assets/js/both.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

<script type="text/javascript">
var BASE_URL = "<?php echo url('/'); ?>/";
</script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
