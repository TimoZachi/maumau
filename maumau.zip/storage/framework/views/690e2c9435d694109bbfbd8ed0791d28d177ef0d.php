<div id="sidebar" class="sidebar" data-color="blue" data-image="<?php echo e(asset('assets/img/sidebar-5.jpg')); ?>">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="#" class="simple-text">MauMau Painel</a>
        </div>
        <ul class="nav">
            <li <?php if(Request::route()->getName() == 'admin.dashboard'): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="pe-7s-graph"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li <?php if(Request::route()->getName() == 'admin.cartas'): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(route('admin.cartas')); ?>">
                    <i class="pe-7s-albums"></i>
                    <p>Cartas</p>
                </a>
            </li>
            <li <?php if(Request::route()->getName() == 'admin.baralhos-e-naipes'): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(route('admin.baralhos-e-naipes')); ?>">
                    <i class="pe-7s-note2"></i>
                    <p>Baralhos e Naipes</p>
                </a>
            </li>
            <li <?php if(Request::route()->getName() == 'admin.modalidades'): ?> class="active" <?php endif; ?>>
                <a href="<?php echo e(route('admin.modalidades')); ?>">
                    <i class="pe-7s-science"></i>
                    <p>Modalidades</p>
                </a>
            </li>
        </ul>
    </div>
</div>