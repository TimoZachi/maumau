

<?php $__env->startSection('title', 'Cadastro'); ?>

<?php $__env->startSection('wrapper'); ?>
    <div class="main-panel main-panel-full">
        <div class="content">
            <div class="card">
                <div class="header">
                    <h4 class="title">Cadastre-se</h4>
                </div>
                <div class="content">
                    <form class="form" action="<?php echo e(route('register')); ?>" method="post">
                        <?php echo method_field('post'); ?>

                        <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?> ">
                            <label class="control-label">Nome</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                            <p class="help-block"><?php echo e($errors->first('name')); ?></p>
                        </div>
                        <div class="form-group <?php if($errors->has('email')): ?> has-error <?php endif; ?> ">
                            <label class="control-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                            <p class="help-block"><?php echo e($errors->first('email')); ?></p>
                        </div>
                        <div class="form-group <?php if($errors->has('password')): ?> has-error <?php endif; ?> ">
                            <label class="control-label">Senha</label>
                            <input type="password" name="password" class="form-control">
                            <p class="help-block"><?php echo e($errors->first('password')); ?></p>
                        </div>
                        <div class="form-group <?php if($errors->has('password_confirmation')): ?> has-error <?php endif; ?> ">
                            <label class="control-label">Confirmar Senha</label>
                            <input type="password" name="password_confirmation" class="form-control">
                            <p class="help-block"><?php echo e($errors->first('password_confirmation')); ?></p>
                        </div>
                        <div class="form-group text-right">
                            <input type="submit" class="btn btn-primary btn-fill" value="Cadastrar">
                        </div>
                        <?php echo csrf_field(); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.raw', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>