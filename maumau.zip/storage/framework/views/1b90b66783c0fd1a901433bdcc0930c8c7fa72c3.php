

<?php $__env->startSection('title', 'Jogar'); ?>

<?php $__env->startSection('content'); ?>

<script type="text/javascript">
window.CONFIG = {
    user:<?php echo json_encode($user); ?>,
    token:"<?php echo e($token); ?>",
    host:"<?php echo e(explode('/', preg_replace('/^https?:\\/\\//', '', url('/')))[0]); ?>",
    port:"<?php echo e($port); ?>"
};
</script>

<div id="sidebar" class="sidebar">
    <div class="logo">
        <a href="<?php echo e(route('home')); ?>" class="center-block-absolute">
            <img src="<?php echo e(asset('assets/img/logo-small.png')); ?>">
        </a>
    </div>
    <div class="toggle-button">
        <button type="button" id="btn-toggle-table" class="btn btn-primary" disabled>
            Sentar em uma cadeira livre
        </button>
    </div>
    <div id="main-panel" class="panel panel-default">
        <div class="panel-heading">Jogadores Conectados</div>
        <div class="panel-body online">
            <table id="table-players" class="table table-striped">
                <thead>
                <tr>
                    <th width="40" class="text-center">#</th>
                    <th>Jogador</th>
                </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>
<div class="game">
    <div class="game-inside">
        <div id="game-table" class="game-table center-block-absolute" style="display:none;">
            <img src="<?php echo e(asset('assets/img/table.png')); ?>" class="center-block-absolute">
            <div class="user1">
                <div class="frame"></div>
                <p></p>
            </div>
            <div class="user2">
                <div class="frame"></div>
                <p></p>
            </div>
            <div class="user3">
                <div class="frame"></div>
                <p></p>
            </div>
            <div class="user4">
                <div class="frame"></div>
                <p></p>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    @parent

    <script type="text/javascript" src="<?php echo e(asset('assets/js/class/EventDispatcher.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/class/WSWrapper.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/pages/jogar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>