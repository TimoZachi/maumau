

<?php $__env->startSection('title', 'Modalidades'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <button class="btn btn-info btn-fill pull-right top-action"
                            data-toggle="modal" data-target="#modal-modality"
                            data-load="<?php echo e(route('admin.modalities.create')); ?>"
                    >
                        <i class="icon pe-7s-plus"></i>&nbsp;Nova
                    </button>
                    <h4 class="title">Modalidades</h4>
                </div>
                <div class="content table-responsive table-full-width">
                    <?php echo App::make('\MauMau\Http\Controllers\Admin\ModalityController')->index()->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>