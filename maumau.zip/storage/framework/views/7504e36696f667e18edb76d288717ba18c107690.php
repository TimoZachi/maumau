<?php echo $__env->make('admin.cards.form', [
    'id' => $id,
    'route' => route('admin.cards.update', ['id' => $id]),
    'method' => 'put',
    'title' => 'Editando Carta',
    'card' => $card
], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>