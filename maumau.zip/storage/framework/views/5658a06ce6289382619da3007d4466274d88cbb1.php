

<?php $__env->startSection('title', 'Baralhos e Naipes'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <button class="btn btn-info btn-fill pull-right top-action"
                            data-toggle="modal" data-target="#modal-deck"
                            data-load="<?php echo e(route('admin.decks.create')); ?>"
                    >
                        <i class="icon pe-7s-plus"></i>&nbsp;Novo
                    </button>
                    <h4 class="title">Baralhos</h4>
                </div>
                <div class="content table-responsive table-full-width">
                    <?php echo App::make('\MauMau\Http\Controllers\Admin\DeckController')->index()->render(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <button class="btn btn-info btn-fill pull-right top-action"
                            data-toggle="modal" data-target="#modal-suit"
                            data-load="<?php echo e(route('admin.suits.create')); ?>"
                    >
                        <i class="icon pe-7s-plus"></i>&nbsp;Novo
                    </button>
                    <h4 class="title">Naipes</h4>
                </div>
                <div class="content table-responsive table-full-width">
                    <?php echo App::make('\MauMau\Http\Controllers\Admin\SuitController')->index()->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>