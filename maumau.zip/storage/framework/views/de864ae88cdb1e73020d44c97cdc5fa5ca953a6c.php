<div class="deck clearfix ajax-content"
     data-refresh="<?php echo e(route('admin.cards.index')); ?>"
>
    <?php $__empty_1 = true; foreach($cards as $card): $__empty_1 = false; ?>
        <?php echo $__env->make('card-template', ['card' => $card, 'tag' => 'div', 'icons' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endforeach; if ($__empty_1): ?>
        <div class="none">
            <span>Nenhuma carta cadastrada</span>
        </div>
    <?php endif; ?>
</div>

<?php $__env->startSection('modals'); ?>
    @parent

    <div id="modal-card" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content card">
            </div>
        </div>
    </div>
    <div id="modal-card-delete" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content card">
                <form id="form-card-delete" action="<?php echo e(route('admin.cards.destroy', ['id' => '00'])); ?>" method="POST" class="form-horizontal"
                      data-ajax="true" data-ajax-refresh=".deck"
                >
                    <?php echo method_field('delete'); ?>

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Excluir Carta</h4>
                    </div>
                    <div class="modal-body">
                        <p>Tem certeza que deseja excluir esta Carta?</p>
                    </div>
                    <div class="modal-footer">
                        <?php echo csrf_field(); ?>

                        <button type="button" class="btn btn-danger btn-fill" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-info btn-fill">Excluir</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>