<<?php echo e($tag); ?> class="game-card <?php echo e(isset($class) ? $class : ''); ?>" data-id="<?php echo e($card['id']); ?>"<?php echo isset($style) ? ' style="' . $style . '"' : ''; ?>

            data-require-suit="<?php echo e((empty($card['suit_id']) || ($card['Action'] && $card['Action']['require_suit'])) ? 1 : 0); ?>"
>
    <div class="info">
        <div class="item"><?php echo e($card['name']); ?></div>
        <?php if($card['Suit']): ?>
            <div class="item">
                <img src="<?php echo e(asset('assets/img/upload/suits/' . $card['Suit']['icon'])); ?>" width="15">
            </div>
        <?php endif; ?>
    </div>
    <?php if(isset($icons) && $icons): ?>
        <div class="icons">
            <a href="#" title="Editar"
               data-toggle="modal" data-target="#modal-card"
               data-load="<?php echo e(route('admin.cards.edit', ['id' => $card['id']])); ?>"
            >
                <b class="fa fa-edit"></b>
            </a>
            <a href="#" class="delete" title="Excluir"
               data-toggle="modal" data-target="#modal-card-delete"
               data-action="<?php echo e(route('admin.cards.destroy', ['id' => $card['id']])); ?>"
            >
                <b>&times;</b>
            </a>
        </div>
    <?php endif; ?>
    <?php if(empty($card['image'])): ?>
        <div class="large fit-height"><?php echo e($card['name']); ?></div>
    <?php else: ?>
        <div class="large center-block-absolute">
            <img src="<?php echo e(asset('assets/img/upload/cards/' . $card['image'])); ?>">
        </div>
    <?php endif; ?>
    <div class="info-bottom">
        <?php if($card['Suit']): ?>
            <div class="item">
                <img src="<?php echo e(asset('assets/img/upload/suits/' . $card['Suit']['icon'])); ?>" width="15">
            </div>
        <?php endif; ?>
        <div class="item"><?php echo e($card['name']); ?></div>
    </div>
</<?php echo e($tag); ?>>