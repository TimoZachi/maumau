

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('wrapper'); ?>
    <div class="main-panel main-panel-full">
        <div class="content">
            <div class="card">
                <div class="header">
                    <h4 class="title">Login</h4>
                </div>
                <div class="content">
                    <?php if($errors->has('email') || $errors->has('password')): ?>
                        <div class="alert alert-danger">
                            <button type="button" aria-hidden="true" class="close" data-dismiss="alert">×</button>
                            <span>Email e/ou senha incorretos</span>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('logout')): ?>
                        <div class="alert alert-info">
                            <button type="button" aria-hidden="true" class="close" data-dismiss="alert">×</button>
                            <span>Logout realizado com sucesso</span>
                        </div>
                    <?php endif; ?>
                    <form class="form" action="" method="post">
                        <?php echo method_field('post'); ?>

                        <div class="form-group">
                            <label class="control-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                        </div>
                        <div class="form-group">
                            <label class="control-label">Senha</label>
                            <input type="password" name="password" class="form-control">
                        </div>
                        <label class="checkbox">
                            <input type="checkbox" name="remember" value="1" data-toggle="checkbox">
                            Lembrar
                        </label>
                        <div class="form-group text-right">
                            <input type="submit" class="btn btn-primary btn-fill" value="Login">
                        </div>
                        <?php echo csrf_field(); ?>

                    </form>
                    <p>Não tem login? <a href="<?php echo e(route('register')); ?>">Cadastre-se</a></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.raw', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>