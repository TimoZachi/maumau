<table id="table-decks" class="table table-hover table-striped" data-refresh="<?php echo e(route('admin.decks.index')); ?>">
    <thead>
        <th width="40">ID</th>
        <th>Nome</th>
        <th>Naipes</th>
        <th>Nº de Cartas</th>
        <th width="120" class="text-right">Ação</th>
    </thead>
    <tbody class="ajax-content">
        <?php $__empty_1 = true; foreach($decks as $deck): $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($deck['id']); ?></td>
                <td><?php echo e($deck['name']); ?></td>
                <td><?php echo e($deck['suits_count']); ?></td>
                <td><?php echo e($deck['cards_count']); ?></td>
                <td class="td-actions text-right">
                    <a rel="tooltip" class="btn btn-info btn-simple btn-xs action" title="Associar Cartas"
                       href="<?php echo e(route('admin.baralhos-associar-cartas', ['id' => $deck['id']])); ?>"
                    >
                        <i class="pe-7s-albums"></i>
                    </a>
                    <button type="button" rel="tooltip" class="btn btn-info btn-simple btn-xs action" title="Editar Baralho"
                            data-toggle="modal" data-target="#modal-deck"
                            data-load="<?php echo e(route('admin.decks.edit', ['id' => $deck['id']])); ?>"
                    >
                        <i class="fa fa-edit"></i>
                    </button>
                    <button type="button" rel="tooltip" class="btn btn-danger btn-simple btn-xs action delete" title="Excluir"
                            data-toggle="modal" data-target="#modal-deck-delete"
                            data-action="<?php echo e(route('admin.decks.destroy', ['id' => $deck['id']])); ?>"
                    >
                        <i class="fa fa-times"></i>
                    </button>
                </td>
            </tr>
        <?php endforeach; if ($__empty_1): ?>
            <tr class="none">
                <td colspan="5">
                    <span>Nenhum baralho cadastrado</span>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php $__env->startSection('modals'); ?>
    @parent

    <div id="modal-deck" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content card">
            </div>
        </div>
    </div>
    <div id="modal-deck-delete" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content card">
                <form id="form-deck-delete" action="<?php echo e(route('admin.decks.destroy', ['id' => '00'])); ?>" method="POST" class="form-horizontal"
                      data-ajax="true" data-ajax-refresh="#table-decks"
                >
                    <?php echo method_field('delete'); ?>

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Excluir Baralho</h4>
                    </div>
                    <div class="modal-body">
                        <p>Tem certeza que deseja excluir este Baralho?</p>
                    </div>
                    <div class="modal-footer">
                        <?php echo csrf_field(); ?>

                        <button type="button" class="btn btn-danger btn-fill" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-info btn-fill">Excluir</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>