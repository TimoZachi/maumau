<?php
namespace MauMau\Http\Controllers;

class Controller extends \App\Http\Controllers\Controller
{
	
}