<?php
namespace MauMau\Models;

class DeckCard extends Model
{
	protected $table = 'decks_cards';
}
