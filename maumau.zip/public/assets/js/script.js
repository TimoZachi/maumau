jQuery(function ($)
{

});