<footer class="footer">
    <div class="container-fluid">
        <p class="copyright pull-right">
            &copy; 2016 MauMau Online
        </p>
    </div>
</footer>