@extends('admin.layout')

@section('title', 'Dashboard')

@section('content')
    <p>Nada a mostrar.</p>
@endsection